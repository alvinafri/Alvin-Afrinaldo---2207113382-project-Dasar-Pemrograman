<template>
    <div class="Home">
        <p>Home components</p>
    </div>
</template>