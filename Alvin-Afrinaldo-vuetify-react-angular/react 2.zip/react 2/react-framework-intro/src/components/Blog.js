import Info from "./info";
import React from "react";
import '../App.css';

export default function Blog(){
    return (
        <div class="center">
            <h1> Ini Halaman Blog </h1>
            <Info/>
        </div>
    );
}