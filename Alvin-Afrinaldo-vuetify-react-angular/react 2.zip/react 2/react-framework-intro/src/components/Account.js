import Info from "./info";
import React from "react";
import '../App.css';

export default function Account(){
    return (
        <div class="center">
            <h1> Ini Halaman Account </h1>
            <Info/>
        </div>
    );
}